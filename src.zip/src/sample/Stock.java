package sample;

import java.util.HashMap;
import java.util.Iterator;


public class Stock {

    public static HashMap<Integer, Item> data = new HashMap<>();

   // public Stock() {
   //     data = new HashMap<String, Integer>();
   //}

    public static void add(String name,String Type, Integer size, Integer count, Integer price) {
        Item newItem = new Item(name,Type,size,count,price);
        data.put(newItem.getid(),newItem);
    }


    /*public static Integer getStock(String name, Item num) {
        if (data.containsValue(name)) {
            return data.get(num);
        } else
            return null;
    }
    */

    public static int getIdfromName(String name){
        Iterator it = Stock.data.keySet().iterator();
        int theID = -1;
        while (it.hasNext()){
            Integer Mykey = (Integer)(it.next());
            if (data.get(Mykey).getName() == name)  {
                theID = Mykey;
            }
        }
        return theID;
    }

    public static void reduceStock(Integer reduceAmount, Integer Mykey) {
        data.get(Mykey).reduceStock(reduceAmount);
    }

}
