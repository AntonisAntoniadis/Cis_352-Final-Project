package sample;

public class OrderItem {

    //private static int counter = 1;
    private int id;
    private String name;
    private Integer  quantity, price;

    public OrderItem(Integer id,String name, Integer quantity, Integer price) {
        this.id = id;
        //counter ++;
        this.name = name;

        this.price = price;
        this.quantity = quantity;
    }

    public Integer getid(){
        return id;
    }

    public String getName(){
        return this.name;
    }


    public Integer getPrice(){
        return this.price;
    }

    public Integer getQuantity(){
        return this.quantity;
    }



    //@Override
  //  public String toString() {
   //     return ("Name: " + name + "  Item stock: " + quantity + "  Price: " +price + "€\n");
  //  }

}
