package sample;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.ComboBoxListCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Types;
import java.util.Iterator;


public class Main extends Application {

    static ObservableList<String> productoptions;
    static String selected_Type, statusoforder1,statusoforder2,statusoforder3;
    Scene sc1,sc2,sc3,sc4;
    HBox hbox1,hbox2,hbox3,hbox4,layout1,hbox5,hbox6,hbox7,hbox8,hbox9,hbox10,hbox11,hbox12,hbox13;
    VBox vbox1,layout0,vbox2,layout2,layout3,vbox3;
    Label label1,label2,label3,label5,label6,label7,label8,label9,label10,label15,label16,label17,label18,label19,label20;
    static Label label4,label11,label12,label13,label14;
    Button b1,b2,b3,b4,b6,b7,b8,b9,b10,b11,b12,b13;
    static ComboBox products, orders;



    @Override
    public void start(Stage primaryStage) throws Exception {
        filldata();



        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        primaryStage.setTitle("ShoeStore");

        label1 = new Label("            Welcome!\nSelect the Type of shoes :");
        label2 = new Label("Please Select the Shoes you'd like to buy!");
        label3 = new Label("0");
        label4 = new Label("");
        label4.setStyle("-fx-background-color:#C0C0C0");
        label4.setPadding(new Insets(5));
        label5 = new Label("");
        label6 = new Label("");
        label7 = new Label("");
        label8 = new Label("0");
        label9 = new Label("Total Price : ");
        label10 = new Label("€");
        label11 = new Label(" ");
        label12 = new Label(" ");
        label13 = new Label(" ");
        label14 = new Label("0");
        label15 = new Label("Total Price : ");
        label16 = new Label("€");
        label17 = new Label("Status of Orders");
        label18 = new Label(" ");
        label19 = new Label(" ");
        label20 = new Label(" ");
        hbox1 = new HBox(40);
        hbox2 = new HBox(40);
        hbox3 = new HBox(40);
        hbox4 = new HBox(40);
        hbox5 = new HBox(5);
        hbox6 = new HBox(40);
        hbox7 = new HBox(20);
        hbox8 = new HBox(20);
        hbox9 = new HBox(20);
        hbox10 = new HBox(20);
        hbox11 = new HBox(20);
        hbox12 = new HBox(20);
        hbox13 = new HBox(20);
        vbox2 = new VBox(20);
        vbox3 = new VBox(50);



        ObservableList<String> productType =
                FXCollections.observableArrayList();

        Iterator it0 = Stock.data.keySet().iterator();
        boolean isNewType;
        while (it0.hasNext()){
            isNewType = true;
            Integer Mykey = (Integer)(it0.next());
            Iterator it0_2 = productType.iterator();
            while (it0_2.hasNext()) {
                if (it0_2.next() == Stock.data.get(Mykey).getType()){
                    isNewType = false;
                }
            }
            if (isNewType) {
                productType.add(Stock.data.get(Mykey).getType());
            }
        }
        ComboBox Types1 = new ComboBox(productType);
        Types1.getSelectionModel().selectFirst();


        productoptions = FXCollections.observableArrayList();
        products = new ComboBox(productoptions);

        ListView<String> orderslist = new ListView<String>();
        ObservableList<String> items =FXCollections.observableArrayList (
                "Order1", "Order2", "Order3");
        orderslist.setItems(items);
        orders = new ComboBox(items);

        b1 = new Button("Enter!");
        b2 = new Button("-");
        b3 = new Button("+");
        b4 = new Button("Proceed to Checkout!");

        b6 = new Button("Go Back!");
        b7 = new Button("Add to Cart!");
        b8 = new Button("Clear Cart!");
        b9 = new Button("Go Back!");
        b10 = new Button("Finalize Order!");
        b11 = new Button("List of Orders");
        b12 = new Button("Status!");
        b13 = new Button("Status Update!");

        hbox11.getChildren().addAll(b11);
        hbox11.setAlignment(Pos.BOTTOM_RIGHT);
        layout0 = new VBox(40);
        layout0.setAlignment(Pos.CENTER);
        layout0.getChildren().addAll(label1, Types1,b1,hbox11);
        hbox1.getChildren().addAll(label4);
        hbox1.setAlignment(Pos.CENTER);
        hbox2.setAlignment(Pos.CENTER);
        hbox2.getChildren().addAll(label2);
        hbox2.setSpacing(50);
        hbox3.setAlignment(Pos.CENTER);
        hbox3.getChildren().addAll(products, b2, label3, b3);
        hbox4.getChildren().addAll(b6,b4);
        hbox4.setAlignment(Pos.CENTER);
        hbox5.getChildren().addAll(label5,label6,label7);
        hbox5.setPrefSize(200,500);
        hbox6.getChildren().addAll(b8,b7);
        hbox6.setAlignment(Pos.CENTER);
        hbox7.getChildren().addAll(label9,label8,label10);
        hbox7.setAlignment(Pos.BOTTOM_RIGHT);
        hbox7.setPrefSize(200,100);
        hbox8.getChildren().addAll(label11,label12,label13);
        hbox9.getChildren().addAll(label15,label14,label16);
        hbox10.getChildren().addAll(b9,b10);
        hbox12.getChildren().addAll(orders,label17);
        hbox13.getChildren().addAll(b12,b13);
        vbox1 = new VBox(40);
        vbox1.setAlignment(Pos.CENTER);
        vbox1.getChildren().addAll(hbox2,hbox1, hbox3,hbox6,hbox4);
        vbox1.setPrefWidth(400);
        vbox2.getChildren().addAll(hbox5,hbox7);
        vbox2.setPrefSize(200,400);
        vbox3.getChildren().addAll(hbox13,label18,label19,label20);
        vbox3.setAlignment(Pos.CENTER);

        layout1 = new HBox();
        layout1.getChildren().addAll(vbox1,vbox2);
        layout2 = new VBox();
        layout2.getChildren().addAll(hbox8,hbox9,hbox10);
        layout3 = new VBox();
        layout3.getChildren().addAll(hbox12,vbox3);




        b1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                selected_Type  = (String)Types1.getValue();
                fillSecondDropDownMenu();


                primaryStage.setScene(sc2);

            }
        });

        sc1 = new Scene(layout0, 400, 400);
        primaryStage.setScene(sc1);
        primaryStage.show();

        sc2 = new Scene(layout1, 600, 400);
        sc3 = new Scene (layout2,400,400);
        sc4 = new Scene (layout3,400,400);

        b2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                String x = label3.getText();
                Integer xx = Integer.parseInt(x);
                if (xx > 0) {
                    xx--;
                    label3.setText("" + xx);
                }
            }
        });
        b3.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                String x = label3.getText();
                Integer xx = Integer.parseInt(x);
                xx++;
                label3.setText("" + xx);
            }
        });
        b4.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                label11.setText(label5.getText());
                label12.setText(label6.getText());
                label13.setText(label7.getText());
                label14.setText(label8.getText());
                primaryStage.setScene(sc3);
            }
        });
        b6.setOnAction(e -> primaryStage.setScene(sc1));
        b7.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                int thisKey = Stock.getIdfromName((String)products.getValue());
                int thisValue = Stock.data.get(thisKey).getPrice()  * Integer.parseInt(label3.getText());
                if (Order.order.containsKey(thisKey)) {
                    //Error
                    Alert dialog1 = new Alert(Alert.AlertType.INFORMATION);
                    dialog1.setTitle("Error");
                    dialog1.setHeaderText(null);
                    dialog1.setContentText("Product already exists");
                    dialog1.showAndWait();
                }
                else {
                    label5.setText(label5.getText() + products.getValue() + "\n");
                    label6.setText(label6.getText() + label3.getText() + "\n");

                    label7.setText(label7.getText() + thisValue + "€\n");
                    label8.setText((Integer.parseInt(label8.getText()) + thisValue) + "");
                    Order.add(thisKey, Stock.data.get(thisKey).getName(), Integer.parseInt(label3.getText()), thisValue);
                }
            }
        });
        b8.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                clearMyCart();

                //label5.setText("");
                //label6.setText("");
                //label7.setText("");
                //label8.setText("0");
                //Order.clearOrder();
            }
        });
        b9.setOnAction(e -> primaryStage.setScene(sc2));
        b10.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Iterator it4 = Order.order.keySet().iterator();
                boolean inStock = true;
                String errorMessage = " ";
                while (it4.hasNext()){
                    Integer Mykey = (Integer)(it4.next());
                    OrderItem myOrderItem = Order.order.get(Mykey);
                    Item myItem = Stock.data.get(Mykey);
                    if (myOrderItem.getQuantity() > myItem.getCount()) {
                        inStock = false;
                        errorMessage = errorMessage + myOrderItem.getName() + " is out of Stock.\n";
                    }

                }
                if (inStock) {
                    Alert dialog2 = new Alert(Alert.AlertType.INFORMATION);
                    dialog2.setTitle("Making the Sale");
                    dialog2.setHeaderText("Your Purchase was successfully listed");
                    dialog2.setContentText(null);
                    dialog2.showAndWait();


                    Iterator it5 = Order.order.keySet().iterator();
                    while (it5.hasNext()){
                        Integer Mykey = (Integer)(it5.next());
                        OrderItem myOrderItem = Order.order.get(Mykey);
                        Integer reduceAmount = myOrderItem.getQuantity();
                        Stock.reduceStock(reduceAmount, Mykey);
                    }

                }
                else {
                    Alert dialog3 = new Alert(Alert.AlertType.ERROR);
                    dialog3.setTitle("Error in Sale");
                    dialog3.setHeaderText("Your Purchase was unsuccessfull");
                    dialog3.setContentText(errorMessage);
                    dialog3.showAndWait();

                }
                clearMyCart();
                primaryStage.setScene(sc1);

            }
        });
        b11.setOnAction(e -> primaryStage.setScene(sc4));
        b12.setOnAction(e -> statusOrder());
        b13.setOnAction(e -> statusOrder());
    }

    public void filldata() {

        Stock.add("Sports Shoe 1","Sports", 45, 10, 50);
        Stock.add("Sports Shoe 2","Sports", 43, 10, 40);
        Stock.add("Formal Shoe 3","Formal", 47, 15, 350);
        Stock.add("Formal Shoe 4","Formal", 39, 20, 200);
        Stock.add("Heels Shoe 5","Heels", 38, 26, 30);
        Stock.add("Heels Shoe 6","Heels", 35, 5, 20);
        Stock.add("Heels Shoe 7","Heels", 36, 3, 55);


        /*
        Iterator it = Stock.data.keySet().iterator();
        while (it.hasNext()){
            Integer Mykey = (Integer)(it.next());
            Item myItem = Stock.data.get(Mykey);
            //(Stock.data.get(Mykey).getName());
        }

         */
    }

  /*  public void PrintSpecificType(String Type){
        Interator interator = data.interator
    }
   */
    public void  fillSecondDropDownMenu(){
        productoptions.clear();
        label4.setText("");
        Iterator it1 = Stock.data.keySet().iterator();

        while (it1.hasNext()){
            Integer Mykey = (Integer)(it1.next());

            if (Stock.data.get(Mykey).getType() == selected_Type) {
                productoptions.add(Stock.data.get(Mykey).getName());
                label4.setText( label4.getText() + Stock.data.get(Mykey).toString() );
            }
        }
        products.getSelectionModel().selectFirst();
       // return products1;
    }

    public void clearMyCart() {
        label5.setText("");
        label6.setText("");
        label7.setText("");
        label8.setText("0");
        Order.clearOrder();
    }

    public void statusOrder() {
        String status = "Received -> ";
        if (b12.isHover()){
            statusoforder1 = status + "Prepared";
            label18.setText(statusoforder1);
        }
        else if (b13.isHover()) {
            statusoforder2 = "Prepared -> " + "Delivered";
            label19.setText(statusoforder2);
        }
    }


    public static void main(String[] args) {
        launch(args);
    }
}
