package sample;

public class Item {

    private static int counter = 1;
    private int id;
    private String name, Type;
    private Integer size, count, price;

    public Item(String name,String Type, Integer size, Integer count, Integer price) {
        id = counter;
        counter ++;
        this.name = name;
        this.Type = Type;
        this.size = size;
        this.price = price;
        this.count = count;
    }

    public Integer getid(){
        return id;
    }

    public String getName(){
        return this.name;
    }

    public String getType(){
        return this.Type;
    }

    public Integer getSize(){
        return this.size;
    }

    public Integer getPrice(){
        return this.price;
    }

    public Integer getCount(){
        return this.count;
    }

    public boolean CheckCount (Integer count){
        return  (count <= this.count);

    }

    public void ReduceCount (Integer count){
        this.count = this.count - count;
    }



    @Override
    public String toString() {
        return ("Name: " + name + "  Item stock: " + count + "  Size: " + size + "  Price: " +price + "€\n");
    }

    public void reduceStock(Integer reduceAmount) {
        count = count - reduceAmount;
    }
}
