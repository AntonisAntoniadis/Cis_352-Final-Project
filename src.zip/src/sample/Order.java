package sample;

import java.util.HashMap;
import java.util.Iterator;


public class Order {

    public static HashMap<Integer, OrderItem> order = new HashMap<>();

    // public Stock() {
    //     data = new HashMap<String, Integer>();
    //}

    public static void add(Integer id, String name, Integer quantity, Integer price) {
        OrderItem newOrderItem = new OrderItem(id,name,quantity,price);
        order.put(newOrderItem.getid(),newOrderItem);
    }


    public static void clearOrder() {
        Iterator it3 = order.keySet().iterator();
        while (it3.hasNext()){
            //Integer Mykey = (Integer)(it3.next());
            order.remove(it3.next());
        }
    }


}
